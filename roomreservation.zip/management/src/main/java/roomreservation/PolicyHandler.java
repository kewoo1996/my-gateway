package roomreservation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import roomreservation.config.kafka.KafkaProcessor;

@Service
public class PolicyHandler{
    @Autowired
    ManagementRepository managementRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void reserved(@Payload Reserved reserved){
        Management p = new Management();
        p.setReservationId(reserved.getReservationId());
        p.setCustomerName(reserved.getCustomerName());
        p.setCardInfo(reserved.getCardInfo());
        p.setCustomerPhoneNumber(reserved.getCustomerPhoneNumber());
        p.setRequestDate(reserved.getRequestDate());
        p.setReservationDate(reserved.getReservationDate());
        p.setRoomInfo(reserved.getRoomInfo());
        managementRepository.save(p);
        System.out.println("==============insert===============");
    }

    /*@StreamListener(KafkaProcessor.INPUT)
    public void reservationCanceled(@Payload ReservationCanceled reservationCanceled){
        managementRepository.deleteById(reservationCanceled.getReservationId());
        System.out.println("==============delete===============");
    }*/
}
