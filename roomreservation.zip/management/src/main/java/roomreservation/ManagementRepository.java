package roomreservation;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface ManagementRepository extends PagingAndSortingRepository<Management, Long>{


}